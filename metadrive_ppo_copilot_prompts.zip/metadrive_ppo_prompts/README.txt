# MetaDrive × PPO：GitHub Copilotへ渡すプロンプト

作成日：2026-11-19
対象：別PCにある現在のMetaDrive／SB3 PPOプロジェクト
この一式は依頼文です。ここではリポジトリの実装変更や学習を実行していません。

## ファイル

01_implement_diagnostics.txt
  学習中の全ステップ記録、PPO診断、途中モデル保存、Python集計、
  ダブルクリックで開くHTMLを実装し、短い動作確認まで行う依頼。
  対象実験の本学習は開始しません。

02_rerun_from_report.txt
  指定した既存結果HTMLの元の学習条件を調べ、
  診断付きで新規学習し、新しいHTMLを生成・確認する依頼。
  旧HTMLだけでなくモデル・ログ等も保全します。

## 使い方

1. 実験PCで対象リポジトリを開きます。
2. Copilotがファイルを編集し、必要なローカルコマンドを実行できる状態にします。
3. 01_implement_diagnostics.txtをチャットへ添付するか、全文を貼り付けて実行を依頼します。
   使用できるモデル名はMAI Code 2 Flashです。
4. 実装と短い検証が終わったこと、READMEとIMPLEMENTATION_STATUS.mdが作られたことを確認します。
5. 02_rerun_from_report.txtのTARGET_RESULT_HTMLを、既存結果HTMLの絶対パスへ置き換えます。
6. 02を添付するか全文を貼り付け、再学習と新規HTML生成を依頼します。
   01と02を同時に実行させないでください。

02の入力例：
TARGET_RESULT_HTML = D:\experiments\previous_run\report\index.html

パスに空白や日本語がある場合も、Copilotには正確な絶対パスを渡してください。
実際のコマンドでの引用符やパス処理は実装側で扱わせます。

## Copilotへの短い開始文

実装時：
添付した01_implement_diagnostics.txtを今回の実装要件として読み、段階AからFまで進めてください。対象実験の本学習は開始せず、実装・短い検証・README作成まで完了してください。

再学習時：
添付した02_rerun_from_report.txtに従って実行してください。TARGET_RESULT_HTMLは「ここに既存HTMLの絶対パス」です。元の学習条件を追跡し、旧成果物を保全した新規runで、学習・集計・新しい診断HTMLの確認まで進めてください。

途中で会話を切り替える場合：
docs/training_diagnostics/IMPLEMENTATION_STATUS.mdとREADMEを読んで、未完了の段階から続けてください。完了済み作業や学習を重複実行せず、次の合格条件を確認してください。

## 仕様の要点

- 学習中のデータが主対象。別途評価は同じものとして扱いません。
- 車両状態、実際の行動、行動分布、報酬を全意思決定ステップで保存します。
- 報酬の計算された候補値と、最終報酬への実効寄与を分けます。
- 行動数・分布構造は実行時に確認し、9個へ固定しません。
- 全体の学習予算終了による未完了走行は成否未確定です。環境内の時間切れによる未到達は失敗です。
- HTMLは重畳が初期表示。系列ON/OFF、縦軸変更、必要時の同一領域内分割に対応します。
- フルHDを基準に、ページを上下に往復せず主要な比較ができる配置を求めます。
- レポートはフォルダ単位でも構いません。入口HTMLをダブルクリックし、閲覧時にサーバーやネットを要求しません。
- 学習ログを保存し、分析閾値や表示変更はPythonで再集計します。表示の修正だけで再学習しません。
- 旧成果物をrun全体で保全します。HTML名だけを変えて旧モデル等を上書きすることは認めません。

## モデルとコストの考え方

正式名称は「MAI Code 2 Flash」です。「MAC Code 2 Flash」ではありません。
GitHub公式は、Flashをコード説明、限定的な編集、日常的な修正、素早い反復等に適したモデルとして紹介しています。
この依頼文では、広い課題を自由に解かせるのではなく、確認対象、実装順、データの定義、具体的な合格条件を指定しています。
ただし、どのモデルでも一度での完全実装は保証できません。自己申告の完了ではなく、列挙した検証結果を確認してください。

クレジットの節約：
- 生ログの数値処理はPythonへ任せます。
- チャットへ渡すのは実装要件、短い集計、異常区間、テストの失敗内容です。
- 進捗ファイルを使い、同じコードや全生ログを何度も読ませません。
- 追加修正は、対象ファイル・再現条件・期待する結果を絞って依頼します。
- 約1,900という枠の種類や消費量はここでは仮定していません。料金・組織の利用設定は実際の契約画面で確認が必要です。

## 技術情報の参照先

モデル名・位置づけ（2026-11-17のGitHub公式発表）：
https://github.blog/changelog/2026-11-17-mai-code-2-and-mai-code-2-flash-in-github-copilot/

SB3の収集・GAE・更新順序の確認例：
https://stable-baselines3.readthedocs.io/en/v2.9.0/_modules/stable_baselines3/common/on_policy_algorithm.html

SB3のPPO更新の確認例：
https://stable-baselines3.readthedocs.io/en/v2.9.0/_modules/stable_baselines3/ppo/ppo.html

VecEnvの終了観測・自動reset：
https://stable-baselines3.readthedocs.io/en/v2.9.0/guide/vec_envs.html

ブラウザの同一オリジンとローカルファイル制約：
https://developer.mozilla.org/en-US/docs/Web/Security/Defenses/Same-origin_policy

これらのSB3リンクは参考版です。実装する際は実験PCで実際に使っている版のコードを確認します。
