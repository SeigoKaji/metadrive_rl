#!/usr/bin/env python3
"""Summarize local public-format evaluation_steps.jsonl files; output is JSONL."""
import argparse
import json
import math
import sys
from collections import Counter
from pathlib import Path

UNAVAILABLE = "UNAVAILABLE"
PARTS = ("r_base", "r_prediction", "r_lateral_accel", "r_pp")
FIELDS = ("step_reward", *PARTS, "r_total")


def number(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if math.isfinite(value):
            return float(value)
    return None


def episode_end(row):
    terminated, truncated = row.get("terminated"), row.get("truncated")
    if not isinstance(terminated, bool) or not isinstance(truncated, bool):
        return "unknown_flags"
    if terminated and truncated:
        return "terminated_and_truncated"
    if terminated:
        return "terminated"
    if truncated:
        return "truncated"
    return "partial_no_end_observed"


class Total:
    def __init__(self):
        self.count = 0
        self.total = self.discounted = self.max_abs = 0.0

    def add(self, value, weight):
        if value is not None:
            self.count += 1
            self.total += value
            self.discounted += value * weight
            self.max_abs = max(self.max_abs, abs(value))

    def report(self, rows, gaps, residual=False):
        complete = rows > 0 and not gaps and self.count == rows
        result = {
            "known_rows": self.count,
            "unavailable_rows": rows - self.count,
            "sum": self.total if complete else UNAVAILABLE,
            "discounted_sum": self.discounted if complete else UNAVAILABLE,
        }
        if residual:
            result["max_abs_on_known_rows"] = self.max_abs if self.count else UNAVAILABLE
        return result


class Episode:
    def __init__(self, gamma, from_step):
        self.gamma, self.from_step = gamma, from_step
        self.last = self.rows = self.gaps = 0
        self.first_kept = None
        self.end = "partial_no_end_observed"
        self.flags = {}
        self.totals = {key: Total() for key in FIELDS}
        self.checks = {key: Total() for key in ("parts_minus_step_reward", "r_total_minus_step_reward")}
        self.validity = {key: Counter() for key in ("prediction", "lateral_accel")}

    def add(self, row, step):
        if step <= self.last:
            raise ValueError("duplicate or out-of-order step")
        if self.end in {"terminated", "truncated", "terminated_and_truncated"}:
            raise ValueError("step follows an episode ending")
        self.last = step
        self.end = episode_end(row)
        for key in ("arrive_dest", "out_of_road", "crash", "max_step"):
            value = row.get(key)
            self.flags[key] = value if isinstance(value, bool) else UNAVAILABLE
        if step < self.from_step:
            return
        if self.first_kept is None:
            self.first_kept = step
        self.rows += 1
        self.gaps = step - self.from_step + 1 - self.rows
        weight = self.gamma ** (step - self.from_step)
        namespace = row.get("lookahead_learning")
        namespace = namespace if isinstance(namespace, dict) else {}
        values = {key: number(namespace.get(key)) for key in (*PARTS, "r_total")}
        values["step_reward"] = number(row.get("step_reward"))
        for key, value in values.items():
            self.totals[key].add(value, weight)
        actual = values["step_reward"]
        if actual is not None and all(values[key] is not None for key in PARTS):
            self.checks["parts_minus_step_reward"].add(math.fsum(values[key] for key in PARTS) - actual, weight)
        if actual is not None and values["r_total"] is not None:
            self.checks["r_total_minus_step_reward"].add(values["r_total"] - actual, weight)
        for key, flag in (("prediction", "valid"), ("lateral_accel", "active")):
            diagnostic = namespace.get(key)
            value = diagnostic.get(flag) if isinstance(diagnostic, dict) else None
            category = ("yes" if value else "no") if isinstance(value, bool) else UNAVAILABLE
            self.validity[key][category] += 1

    def report(self):
        return {
            "discount_origin_step": self.from_step, "first_selected_step": self.first_kept,
            "last_observed_step": self.last, "selected_rows": self.rows,
            "missing_selected_steps_through_last": self.gaps,
            "last_observed_status": self.end, "last_observed_flags": self.flags,
            "scope": "observed_environment_rewards_only",
            "terms": {k: t.report(self.rows, self.gaps) for k, t in self.totals.items()},
            "reconciliation": {k: t.report(self.rows, self.gaps, True) for k, t in self.checks.items()},
            "diagnostic_counts": {
                name: {key: counts[key] for key in ("yes", "no", UNAVAILABLE)}
                for name, counts in self.validity.items()
            },
        }


def summarize(path, file_index, gamma, from_step):
    episodes, groups = {}, {}
    with path.open(encoding="utf-8-sig") as stream:
        for line_no, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError("expected a JSON object")
                episode, step, seed = (row.get(k) for k in ("episode", "step", "scenario_seed"))
                if type(episode) is not int or type(step) is not int or episode < 1 or step < 1:
                    raise ValueError("episode and step must be positive integers")
                if type(seed) is not int:
                    raise ValueError("scenario_seed must be an integer")
                group = row.get("scene_group")
                if group is not None and not isinstance(group, str):
                    raise ValueError("invalid scene_group")
                group_index = groups.setdefault(group, len(groups) + 1) if group is not None else None
                key = (episode, seed, group_index)
                if key not in episodes:
                    episodes[key] = Episode(gamma, from_step)
                episodes[key].add(row, step)
            except (ValueError, OverflowError) as exc:
                raise ValueError(f"input {file_index}, line {line_no}: {exc}") from None
    for (episode, seed, group_index), summary in episodes.items():
        yield {"input_index": file_index, "episode": episode, "scenario_seed": seed,
               "scene_group_index": group_index, "gamma": gamma, **summary.report()}


def main():
    parser = argparse.ArgumentParser(
        description="Read only explicitly listed local JSONL files. Print one aggregate JSON object per episode/scene.",
        epilog=("r_base stays opaque. Discount exponent is step minus --from-step. "
                "Missing fields or gaps yield UNAVAILABLE sums. Partial traces cover observed steps only. "
                "No bootstrap or PPO Advantage is inferred. No files are written."),
    )
    parser.add_argument("files", type=Path, nargs="+", help="one or more evaluation_steps.jsonl files")
    parser.add_argument("--gamma", required=True, type=float, help="discount factor from this run, 0 to 1")
    parser.add_argument("--from-step", type=int, default=1, help="first decision to include, 1-based (default 1)")
    args = parser.parse_args()
    if not 0 <= args.gamma <= 1 or args.from_step < 1:
        parser.error("gamma must be in [0,1] and from-step must be >= 1")
    for index, path in enumerate(args.files, 1):
        try:
            for report in summarize(path, index, args.gamma, args.from_step):
                print(json.dumps(report, allow_nan=False))
        except OSError as exc:
            parser.exit(1, f"input {index}: cannot read file ({type(exc).__name__})\n")
        except ValueError as exc:
            parser.exit(1, f"{exc}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
