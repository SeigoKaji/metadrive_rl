# PPOが交差点で停止する原因の調査

添付HTMLに記録された各実験の設定とログを使い、制動して停止する場合と通過する場合とで、どの報酬項が累積報酬の差を生むかを調べる。停止が報告されているのは交差点シーン。カーブシーンの結果はその実験の記録で確認する。

以下の式と係数例は SeigoKaji/metadrive_rl（840d8ced）、MetaDrive（85e5dadc）、Stable-Baselines3（2.9.0）の公開実装に基づく。各実験で有効だった係数・フラグ・終了処理は、HTMLに対応する実行設定、コード、記録を優先する。公開例の並列数は4、地図は C。これだけでは32並列の対象実験に使われた設定は確定しない。

独自2項はラッパーの既定でともに無効。併用例では両方を有効、Pure Pursuitの操舵誤差の重みを0とする。設定例 official_start_lane_return_lookahead_lateral_accel.toml は横加速度のみ有効で、位置予測は既定の無効のまま。等加速度と等速の併用例が別にある。[既定値](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/checkpoint.py#L35-L46) ／ [等加速度の併用例](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/examples/time_prediction_acceleration_lateral.toml) ／ [等速の併用例](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/examples/time_prediction_lateral.toml) ／ [横項のみの設定](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/configs/official_start_lane_return_lookahead_lateral_accel.toml) ／ [依存バージョン](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/requirements.lock.txt)

## 1．PPOに渡る報酬の組み立て

公開学習経路はホスト環境、先読みラッパー、Monitor、SubprocVecEnv、PPOの順。ここに VecNormalize は見当たらない。以下の $r$ は通常の環境返却値。純粋な時間切れ時のSB3による補正は後述する。対象実装で横加速度項がホストに移植済みなら、ラッパーの r_base に含まれ得る。ホストとラッパーの両方で加算していないか、ラッパー列が0でもホスト内で採点していないかを確認する。[環境生成](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/env_factory.py#L129-L225) ／ [合算](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/env.py#L1512-L1525) ／ [移植時の扱い](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/docs/README.md#L75-L87)

| 項目 | 公開実装の式・参照値 | 有効条件とスケール |
|---|---|---|
| 経路進捗 | $r_d=c_d\,\sigma f(\ell_{\rm now}-\ell_{\rm last})$、標準 $c_d=1$ | 同一の選択レーンに今と直前の座標を射影した縦方向差[m]。現在レーンが候補に含まれればそのレーンで $\sigma=+1$。それ以外は候補先頭と現道路の向きに従い $\sigma=\pm1$。以下の計算例では $f=1$。0.83 mなら+0.83 |
| 速度 | $r_v=c_v\,\sigma\,v_{\rm km/h}/v_{\max,\rm km/h}$、標準 $c_v=0.1$ | 実際の車両設定の最大速度を使う。標準車例80 km/h・正方向では30 km/hで+0.0375、15 km/hで+0.01875、停止で0。係数0なら無効 |
| 先読み位置誤差 | $r_p=-w_p\Delta t\, e/E$、併用例 $w_p=0.1,E=1$ m | $e$ は予測世界座標と固定経路上の参照点のユークリッド距離[m]。二乗・報酬クリップなし。決定間隔0.1 sで誤差1 mあたり−0.01。無効時は0 |
| 必要横加速度 | $r_a=-w_a\Delta t\,[\max(0,v_{\rm post}^2K/A-1)]^2$、併用例 $w_a=0.1,A=0.8$ m/s² | 行動前の有効な経路区間の最大絶対曲率 $K$ [1/m]、行動後の平面速度 [m/s]。標準決定間隔では超過比の二乗に−0.01を掛ける。許容内・直線のみ・参照無効などは0 |
| 終端・イベント | ゴール、道路外、衝突、時間切れの条件に従う | 次節の優先順位で、実際に返却された値だけを合計。標準の cost_function は独立した info で、この学習入口ではPPO報酬に別途加算されない |

標準進捗と先読み用の固定経路の進捗 $S_{\rm proj}$ は座標系もレーンの選び方も異なり得る。特に交差点では、速度×決定間隔や走行距離を実測の進捗報酬と置き換えない。$f$ は標準の use_lateral_reward が有効な場合のみ、$\operatorname{clip}(1-2|\mathrm{offset}|/\mathrm{width},0,1)$ を使う。ここでは無効を前提にした。[標準報酬](https://github.com/metadriverse/metadrive/blob/85e5dadc6c7436d324348f6e3d8f8e680c06b4db/metadrive/envs/metadrive_env.py#L246-L290) ／ [標準係数](https://github.com/metadriverse/metadrive/blob/85e5dadc6c7436d324348f6e3d8f8e680c06b4db/metadrive/envs/metadrive_env.py#L70-L94) ／ [標準車の速度上限](https://github.com/metadriverse/metadrive/blob/85e5dadc6c7436d324348f6e3d8f8e680c06b4db/metadrive/component/pg_space.py#L237-L244) ／ [決定間隔0.02秒×5](https://github.com/metadriverse/metadrive/blob/85e5dadc6c7436d324348f6e3d8f8e680c06b4db/metadrive/envs/base_env.py#L189-L191)

**位置予測。** 行動前後の車体向き差を折り返し、$\hat\kappa=\mathrm{wrap}(\psi_{\rm post}-\psi_{\rm pre})/[(v_{\rm pre}+v_{\rm post})\Delta t/2]$ を計算する。行動後の位置・車体向きからこの曲率の円弧を距離 $D$ 進んだ点が予測点（曲率0なら直進）。等速版は $D=v_{\rm post}T$。等加速度版は $a=(v_{\rm post}-v_{\rm pre})/\Delta t$、減速時は $\tau=\min(T,-v_{\rm post}/a)$、それ以外は $\tau=T$ とし、$D=v_{\rm post}\tau+a\tau^2/2$。目標点も固定経路上を $S_{\rm proj,post}+D$ まで進める。併用例で $T=1$ s。観測入力のクリップは距離誤差に適用されない。

行動後 $v\le0.1$ m/s（0.36 km/h）、前後どちらかが後退、履歴なし・履歴距離 $\le10^{-4}$ m、参照無効、終了または打ち切りではスキップする。等速版は行動後のプレビュー、等加速度版は予測距離 $D$ で照合した参照を使う。等速版では低速判定より先に参照無効となる場合もある。予測時間内に将来止まるという理由だけではスキップしない。減速は予測距離を短くするが、低速閾値より上では自車の横ずれ等で誤差は残り得る。[予測距離](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/prediction.py#L55-L105) ／ [座標と報酬計算](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/prediction.py#L147-L258) ／ [経路端の処理](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/geometry.py#L1397-L1448)

**横加速度。** 時間指定の例では行動前の $[S_{\rm proj},S_{\rm proj}+v_{\rm pre}T]$ を使い、直線は0、円弧は中心線半径の逆数を取る。固定距離指定のときは設定距離を使う。コーナーが先読み区間に少しでも入れば進入前から採点され得る。減速は行動後の $v^2$ と次回以降の先読み距離の双方に効く。超過が大きい領域ではペナルティの大きさは概ね速度の4乗に比例する。$v\le\sqrt{A/K}$ でゼロ。曲率0は常にゼロ。参照生成失敗や終端でゼロになった行と、有効な参照で許容内だった行は区別する。交差点の直進経路で先読み区間に円弧がなければ、横項は停止の直接原因になれない。[横項](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/lateral_acceleration.py#L96-L120) ／ [区間曲率](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/geometry.py#L298-L354) ／ [前後状態と無効条件](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/lookahead_learning/env.py#L918-L1018)

## 2．終了時に実際に支払われる報酬

| 事象 | 標準または設定例 | 通常報酬・フラグへの作用 |
|---|---|---|
| ゴール | 標準+10 | 標準で最優先。最終レーン終点付近の到達判定で、そのステップの進捗・速度を+10に置換。交差点を抜けた後も経路が続けば、受け取るのはその先のゴール |
| 道路外 | 標準−5、公開併用例−200 | ゴール未成立なら置換。レーン外・設定に応じた白黄実線・歩道等を含む。out_of_road_done は終了するかを制御 |
| 衝突 | 車両−5、物体−5、歩道専用0 | 標準の置換順はゴール→道路外→車両→物体→歩道。歩道で先に道路外判定なら道路外の値。建物・人は終了し得るが独立した一律−5の標準項はない。各イベントの報酬分岐は終了フラグとは別に判定 |
| 純粋な時間切れ | 標準に一律罰なし。プロジェクトの timeout_penalty 既定0 | 標準の最終ステップにも進捗・速度を支払う。公開ラッパーの独自2項は terminated または truncated で0。完全静止中なら最終環境報酬も0 |
| プロジェクト拡張の時間切れ | 有効な開始車線タスクの別実験に25の設定あり | 純粋な時間切れで当該ステップから25を引く。成功・失敗等と同時なら重複徴収しない。開始車線目的 off は標準へ早期 return。対象の実験で0かは、実行時設定・ホスト・終端行で確定する |

終了報酬はホストによって適用順が変わり得る。開始車線タスクを有効にした別実験には失敗優先の追加分岐がある。主な比較項は標準報酬と独自2項である。標準 horizon は1000、公開併用例500、対象の実験では実効値を照合する。標準 truncate_as_terminate=False では純粋な時間切れは (terminated=False, truncated=True)。成功・失敗と上限が同時、または truncate_as_terminate=True で時間切れになった場合は両方が真になり得る。[標準の到達・逸脱判定](https://github.com/metadriverse/metadrive/blob/85e5dadc6c7436d324348f6e3d8f8e680c06b4db/metadrive/envs/metadrive_env.py#L218-L290) ／ [終了フラグ](https://github.com/metadriverse/metadrive/blob/85e5dadc6c7436d324348f6e3d8f8e680c06b4db/metadrive/envs/metadrive_env.py#L159-L204) ／ [実際の返却処理](https://github.com/metadriverse/metadrive/blob/85e5dadc6c7436d324348f6e3d8f8e680c06b4db/metadrive/envs/base_env.py#L606-L639) ／ [プロジェクトの既定](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/start_lane_env.py#L25-L46) ／ [拡張の適用順](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/start_lane_env.py#L758-L859) ／ [時間切れ25の別実験](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/configs/03_official_start_lane_return_timeout_penalty.toml)

## 3．停止と通過の報酬差

比較は同じ実験の制動直前から始める。位置・姿勢・速度・直前の行動履歴・交通・残り時間が対応しているかを確かめる。初速30 km/hだけから、交差点内の速度や各ステップの経路進捗は決まらない。減速中にも進捗や減点が生じるため、停止枝にはブレーキをかけ始めた決定から時間切れ等までを含める。通過枝にはその後のゴール・失敗までを含める。

各項の割引和を $G_i=\sum_{t=0}^{H-1}\gamma^t r_{i,t}$ とし、同じ分岐状態で「通過を試みる枝の $G_i$ − 停止を試みる枝の $G_i$」を計算する。負の差が最大の項は通過を最も不利にし、正の差が最大の項は通過に最も有利に働く。全項を合計した差が負なら、その比較条件では停止が有利である。成功や失敗を含む期待値を出す場合は、全試行の件数とばらつきを併記する。

終端で通常報酬が置き換わった決定では、実際に支払われた寄与だけを足す。第1決定の割引係数は1、ゴールが第 $n$ 決定なら成功報酬の寄与は $\gamma^{n-1}r_{\rm goal}$。未記録の内訳は空欄にし、確認済みの0と区別する。具体的な曲率と軌跡を仮定した数値は `examples/illustrative_returns.md` に収録した。

## 4．なぜPPOが停止行動を強化し得るか

同じ交差点状態 $s$ の比較指標は $\Delta_i=E[G_i\mid\mathrm{通過枝}]-E[G_i\mid\mathrm{停止枝}]$。総和が負なら定義した枝の間で停止有利。最も負の $\Delta_i$ が、通過を最も不利にした項。実測した方策全体の優劣には各枝の確率・失敗も含む。過去の方策で採られた初手のAdvantageを検証するには、その更新時の記録が要る。

PPOは現方策で採った行動について価値差を推定する。代表式は $\delta_t=r_t+\gamma V(s_{t+1})-V(s_t)$、$\hat A_t=\sum_{l\ge0}(\gamma\lambda)^l\delta_{t+l}$（真の終端で次状態価値0、境界を越えて別エピソードを連結しない）。同じ状態で前進すると即時の減点や失敗の確率が高く、制動するとその後の損失が小さい場合、制動時の $\hat A_t$ は比較的高くなり得る。逆に直後の進捗減や繰り返す横項・逸脱で前進時のターゲットがその状態の価値を下回れば、前進時の $\hat A_t$ は負になり得る。停止時の環境報酬が0という情報だけからAdvantageの符号は決まらない。

公開例は $\gamma=0.99,\lambda=0.95$、minibatch 64、10 epochs、normalize_advantage=true。クリップ付き方策目的で、各ミニバッチのAdvantageを平均・標準偏差で正規化する。報酬各項の単位・相対重みはここでは調整されない。50ステップ先の成功は割引リターンでは $10(0.99)^{50}=6.05$。一方50ステップ先の**孤立したTD残差**が現時点のGAEに直接掛ける係数は約0.0466で、学習済みcriticが途中の価値を通じて成功を伝えられる。成功軌跡がまれで、決定論的推論で制動が選ばれたという現象は、徐行通過の真のリターンが高い場合にも起き得る。学習中の確率分布、価値予測、Advantageを確認するまで機序は仮説。

32環境では $32\,n_{\rm steps}$ 個の遷移で1 rolloutを構成し、一つの方策を更新する。公開例同様に $n_{\rm steps}=4096$ なら131,072遷移。時間方向の割引率は不変。同じ交差点を32本走っても行動・初期乱数・結果の多様性は実データによる。失敗の少ない徐行通過をサンプルできていたかが重要。

純粋な打ち切りはSB3のVecEnvで done になり、TimeLimit.truncated が真かつ terminal_observation があれば、rollout buffer に入れる報酬に $\gamma V(s_{\rm final})$ が加わる。terminated も真ならこの補正は行わない。自動reset後の観測を使わない。従って、環境が終端で0を返しても、学習側ターゲットの補正は正・負・ゼロのいずれもあり得る。素の環境リターンとこの補正は別に出す。[SB3 2.9.0 収集処理](https://stable-baselines3.readthedocs.io/en/v2.9.0/_modules/stable_baselines3/common/on_policy_algorithm.html) ／ [PPO更新](https://stable-baselines3.readthedocs.io/en/v2.9.0/_modules/stable_baselines3/ppo/ppo.html) ／ [VecEnvの境界](https://stable-baselines3.readthedocs.io/en/v2.9.0/guide/vec_envs.html)

## 5．再学習を避けるための検証順序

1. **実効設定と既存評価を探す。** 対象runの outputs/<実験名>/training/training_metadata.json、学習時CLI・TOML、コードと依存バージョン、outputs/<実験名>/evaluation/evaluation_steps.jsonl と evaluation.json、models/<実験名>.zip の対応を照合する。公開学習入口は learn() 正常終了後に最終モデルを保存する。途中の定期保存はこの入口に見当たらず、モデル・出力はGit管理外。公開ツリーの空ディレクトリだけでは対象モデルの保存状況は分からない。
2. **既存JSONLで比較する。** 公開版は各決定の速度、選択・実適用行動、route_completion、終了・打ち切り、返却された最終 step_reward と lookahead_learning を保存する。後者には r_base, r_prediction, r_lateral_accel, r_total、予測誤差、曲率、有効・無効と理由がある。単位に注意し、info["acceleration"] は正規化されたアクセル・ブレーキ指令、物理加速度は前後の速度差/決定間隔。標準の info["step_reward"] は終端置換前で、評価JSONLのトップレベル step_reward は実際の返却値。ホストの info["episode_reward"] は外側の独自項を含まない可能性がある。既存データに標準進捗と速度がまとまっていれば、判別不能な残差は「ホスト未分解」と記す。
3. **保存モデルがあれば評価する。** 観測・アクション空間、ラッパー、正規化統計、シーンのseed・初期状態・経路・交通を学習時に合わせる。公開版なら同じbundleを指定した evaluate.py の --model と --no-record-gif でステップ記録が得られる。--seed はRL乱数で、地図seedは環境設定が決める。既存結果は同名runで上書きされ得るので、新しい独立した出力先を使う。決定論的推論で現象を再現し、確率的推論では行動乱数のみを変え、通過率・停止率と分散を得る。停止が決定論的推論固有かも区別できる。
4. **同じ状態から枝を比較。** 制動直前の状態までシーンseedと行動prefixを再生し、位置・姿勢・速度・物理履歴・交通・残り時限が揃ったことを検証する。元方策、制動後停止、実現可能な低速通過、必要なら30 km/h通過を評価。実際にゴールするまで、または失敗・時間切れまで追う。強制操作の枝は報酬設計の反実仮想と明記する。複数乱数で比較できるなら失敗も含む対応差・件数・ばらつきを示す。同じ決定論的エピソードをコピーして試行数を増やさない。全エピソード平均に加えて進入前・旋回中・停止後・ゴールを分け、採点有効率、非ゼロ率、有効時平均と全決定平均、割引寄与差を算出する。
5. **モデルがなくても報酬設計は検査できる。** 同じ環境・同じ初期条件で再現可能な制動・徐行・通過の固定操作を評価する。存在する軌跡上で項を差し引く計算は数値寄与の確認に限定し、報酬を変えたときの学習済み方策の反応とは扱わない。直近100エピソードの平均報酬だけでは、どの位置で何が減点され、失敗を何回回避し、どの行動に正のAdvantageが付いたかは識別不能。
6. **再学習は最後。** 過去のrolloutや中間モデルがなく、目的が「なぜ報酬上止まり得るか」を超えて「いつどの更新で停止の選択確率が上がったか」に至るとき、初めて追加計測付き学習を検討する。新しいrunは過去の再現実験であって過去のAdvantageの復元ではない。各rolloutの env_id・episode_id・時刻、観測の識別子、行動と適用指令、旧方策log確率・値予測、報酬内訳と各終了フラグ、terminal_observation の値・bootstrap、計算後の生Advantageとreturn、エントロピー・行動確率（固定した制動直前状態への更新前後の応答）、チェックポイントを記録する。当初の問いに評価で答えられれば、この段階は不要。

[公開の保存処理](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/train.py#L364-L435) ／ [評価記録の生成](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/evaluate.py#L425-L451) ／ [評価のステップループ](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/evaluate.py#L535-L573) ／ [記録フィールド](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/evaluation_visualization.py#L403-L476) ／ [出力・上書き条件](https://github.com/SeigoKaji/metadrive_rl/blob/840d8ced0c97114c7b11822d7d74ad32f718075d/README.md#L51-L71)
